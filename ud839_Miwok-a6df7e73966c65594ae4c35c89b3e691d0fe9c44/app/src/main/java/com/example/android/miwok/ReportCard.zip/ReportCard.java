package com.example.android.miwok;

/**
 * the class is record the report card.
 */

public class ReportCard {
    // the student id (eg. "201701011")
    private String mId;

    // the year of the report
    private int mYear;

    // the special year average score of the student
    private double mAverageScore;

    /**
     * Create a new ReportCard
     *
     * @param id           the id numbers of the student
     * @param year         the special year of the report card
     * @param averageScore the average score the student get
     */
    public ReportCard(String id, int year, double averageScore) {
        mId = id;
        mYear = year;
        mAverageScore = averageScore;
    }

    /**
     * get the student id
     */
    public String getmId() {
        return mId;
    }

    /**
     * set the student id
     */
    public void setmId(String mId) {
        this.mId = mId;
    }

    /**
     * get the year
     */
    public int getmYear() {
        return mYear;
    }

    /**
     * set the year
     */
    public void setmYear(int mYear) {
        this.mYear = mYear;
    }

    /**
     * get the average score
     */
    public double getmAverageScore() {
        return mAverageScore;
    }

    /**
     * set the average socre
     */
    public void setmAverageScore(double mAverageScore) {
        this.mAverageScore = mAverageScore;
    }

    /**
     * get the student id and the special year score
     */
    @Override
    public String toString() {
        String level;
        if (mAverageScore <= 60)
            level = "D";
        else if (mAverageScore <= 70)
            level = "C";
        else if (mAverageScore <= 85)
            level = "B";
        else
            level = "A";

        return "ReportCard:\n" +
                "Id : " + mId + "\n" +
                "Year : " + mYear + "\n" +
                "level : " + level + "\n";
    }
}
